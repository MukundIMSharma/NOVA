
                Data = f.read().strip()